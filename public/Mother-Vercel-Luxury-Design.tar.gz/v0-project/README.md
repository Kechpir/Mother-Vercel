# Маа'За'Тамее - Курс заочных ЭнергоМедитаций

Next.js проект для лендинга курса заочных ЭнергоМедитаций.

## 🚀 Деплой на Vercel

### Шаг 1: Создайте репозиторий на GitHub

1. Перейдите на [GitHub](https://github.com) и создайте новый репозиторий
2. Назовите его, например: `mother-vercel` или `maa-zatamee`
3. **НЕ** инициализируйте его с README, .gitignore или лицензией

### Шаг 2: Подключите локальный репозиторий к GitHub

Выполните следующие команды в терминале (замените `YOUR_USERNAME` и `YOUR_REPO_NAME` на свои значения):

```bash
cd "C:\Users\Full_Errorist\Desktop\Mother"
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git
git branch -M main
git push -u origin main
```

### Шаг 3: Деплой на Vercel

1. Перейдите на [Vercel](https://vercel.com) и войдите в аккаунт
2. Нажмите **"Add New Project"**
3. Импортируйте ваш GitHub репозиторий
4. Vercel автоматически определит настройки Next.js
5. **Важно**: Добавьте переменные окружения в настройках проекта:
   - `NEXT_PUBLIC_SUPABASE_URL` - URL вашего Supabase проекта
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY` - Anon Key из Supabase
6. Нажмите **"Deploy"**

### Шаг 4: Настройка переменных окружения в Vercel

После создания проекта:
1. Перейдите в **Settings** → **Environment Variables**
2. Добавьте:
   - `NEXT_PUBLIC_SUPABASE_URL` = ваш Supabase URL
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY` = ваш Supabase Anon Key
3. Выберите окружения: Production, Preview, Development
4. Сохраните и передеплойте проект

## 📦 Локальная разработка

```bash
# Установка зависимостей
npm install

# Запуск dev сервера
npm run dev

# Сборка для production
npm run build

# Запуск production сервера
npm start
```

## 🔧 Технологии

- **Next.js 14** - React фреймворк
- **TypeScript** - типизация
- **Tailwind CSS** - стилизация
- **Supabase** - база данных
- **Lucide React** - иконки

## 📝 Переменные окружения

Создайте файл `.env.local` в корне проекта:

```env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url_here
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key_here
```

## 🌐 После деплоя

После успешного деплоя вы получите URL вида: `https://your-project.vercel.app`

Vercel автоматически будет деплоить каждое изменение в ветке `main`!
