import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        accent: "#c1a57b",
      },
      fontFamily: {
        hero: ["var(--font-hero)", "Georgia", "serif"],
      },
    },
  },
  plugins: [],
};
export default config;
